package com.yash.oops.programme2;
public interface Shape {
	double area();
}