package com.yash.oops.programme7;

public class Parent {

	public Parent() {
		// TODO Auto-generated constructor stub
	}
	
	public void compareTo(String input1, String input2) {

	}

}