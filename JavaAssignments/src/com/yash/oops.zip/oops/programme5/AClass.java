package com.yash.oops.programme5;

/**
 * 
 * @author sourabh.tank
 *
 */
public class AClass extends CalcAbs {

	@Override
	void sum(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println("The Sum is :"+(a+b));
	}

	

}