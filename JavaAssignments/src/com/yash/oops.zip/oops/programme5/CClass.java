package com.yash.oops.programme5;

/**
 * 
 * @author sourabh.tank
 *
 */
public class CClass extends BClass{
	public CClass() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	
	
	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println("The Multiply is :"+(a*b));

	}
	
	
}