package com.yash.oops.programme5;
/**
 * @author sourabh.tank
 */
public abstract class CalcAbs {
	
	void sum(int a, int b) {
		
	}

	void sub(int a, int b) {
		
	}
	
	void mul(int a, int b) {
		
	}
	
	void div(int a, int b) {
		
	}

}