package com.yash.oops.programme5;

/**
 * 
 * @author tanay.ojha
 *
 */
public class BClass extends AClass {
	public BClass() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	
	
	@Override
	void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println("The Subtraction is :"+(a-b));

	}
	
	
}