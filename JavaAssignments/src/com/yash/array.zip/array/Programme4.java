package com.yash.array;

/**
 * 
 * @author sourabh.tank
 * 		   An Array contain the n numbers you have to find out
 *         combination which satisfy Pythagoras Template. ( Pythagoras
 *         templates:- 3*3+4*4==5*5)
 *         H2 = p2 + B2
 *         25 = 9 + 16
 */
public class Programme4 {
	public static void main(String[] args) {
		
		int [] arr = new int[] {3,3,4,4,5,5};
		
		for (int i = 0; i < arr.length; i++) {
			
		}
		
		
	}

}
