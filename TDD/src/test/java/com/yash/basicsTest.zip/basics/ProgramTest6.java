package com.yash.basics;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ProgramTest6 {
	Program6 s = new Program6();
	
    @Test
    public void testSumOfDigitFromExpression1(){  
    	assertEquals(2107,s.sumOfNumberDivideBy());  
    } 
    
    @Test
    public void testSumOfDigitFromExpression2(){  
    	
}
}
