package com.yash.basics;

public class ProgramTest5 {

}
