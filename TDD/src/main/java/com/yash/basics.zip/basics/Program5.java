package com.yash.basics;

public class Program5 {

}
