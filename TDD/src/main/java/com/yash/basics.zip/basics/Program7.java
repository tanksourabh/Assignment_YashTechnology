package com.yash.basics;

public class Program7 {
	  public String decimalToBinary(int num) {
	    	return Integer.toBinaryString(num);
	    }
}
